index
{
  "name": "Global Nexus Intl",
  "short_name": "GNI",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#0a3d62",
  "theme_color": "#0a3d62",
  "icons": [
    {
      "src": "icon.png",
      "sizes": "512x512",
      "type": "image/png"
